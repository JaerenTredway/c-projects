#include <stdio.h>
#include <string.h>
#include <ctype.h>

/*  
 * DNA counting lab, assignment #5
 * author: Jaeren Tredway
 * compile, run, and test with these commands:
 * 		gcc Tredway_J_DNA.c
 * 		./a.out < dnaInput_1 > myOutput
 * 		diff myOutput outputFile_1
 */

int main(int argc, char *argv[]) {


	// make sure there is one command line arg:
	// from this call: ./a.out < dnaInput_1 > myOutput
	if (argc != 1) {
		printf("Required: one command line arg.\n");
		return 1;
	}


	// variables:
	unsigned int counterA = 0;
	unsigned int counterC = 0;
	unsigned int counterG = 0;
	unsigned int counterT = 0;
	float percentA = 0.0;
	float percentT = 0.0;
	float percentC = 0.0;
	float percentG = 0.0;
	char c;
	int index;
	char myData[100];
	int numBases; // assign this after the input is read in


	// FIXME input reader:
	index = 1;
	c = getchar(); //FIXME: I think this is the segmentation fault because the executable file is not getting read in with ./a.out < dnaInput_1 > myOutput
	while (c != EOF) {
		if (c != ' ' && c != '\n' && c != '\t') {
			myData[index] = getchar();
		} else if (c == ' ' || c == '\n' || c == '\t') {
			break;
		} else {
			printf("Bad DNA encountered, aborting program.\n");
			return 1;
		}
		index++;
	}
	numBases = strlen(myData);


	// loop over each char in the given input string and
	// update the value of the counters:
	for (int i = 0; i < strlen(myData); i++ ) {
		char nucleic = toupper(myData[i]);
		switch (nucleic) {
			case 'A' : 
				counterA++;
				break;
			case 'C' : 
				counterC++;
				break;
			case 'G' : 
				counterG++;
				break;
			case 'T' : 
				counterT++;
				break;
			default : 
				printf("Bad input encountered, terminating program.");
				return(1);
		}
	}

	// calculate percentages and output results:
	percentA = ( (float)counterA / (float)numBases) * 100;
	percentC = ( (float)counterC / (float)numBases) * 100;
	percentG = ( (float)counterG / (float)numBases) * 100;
	percentT = ( (float)counterT / (float)numBases) * 100;

	printf("The DNA sequence has %d bases\n", numBases);
	printf("%6.2f%% of the bases are A\n", percentA);
	printf("%6.2f%% of the bases are C\n", percentC);
	printf("%6.2f%% of the bases are G\n", percentG);
	printf("%6.2f%% of the bases are T\n", percentT);


	//TESTS:
	printf("arg[0]: %s\narg[1]: %s\narg[2]: %s\n", argv[0], argv[1], argv[2]);
	printf("%c\n", myData[0]);

	return 0; 
}//END main()

